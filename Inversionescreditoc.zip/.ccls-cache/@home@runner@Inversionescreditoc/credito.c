  {
    printf("Ingrese el monto del crédito: ");
    scanf("%f", &monto_credito);
    printf("Ingrese la tasa de interés (en porcentaje): ");
    scanf("%f", &tasa_interes);
    printf("Ingrese el número de años: ");
    scanf("%d", &num_años);
    tasa_interes = tasa_interes /100;
    interes_anual = monto_credito * tasa_interes;
    cuota_mensual_anual = monto_credito * ((tasa_interes * pow(1 + tasa_interes, num_años)) / (pow(1 + tasa_interes, num_años) - 1));
    printf("\nIntereses por año:\n");
    for (int i = 1; i <= num_años; i++) {
        printf("Año %d: %.2f\n", i, interes_anual);
    }
    printf("\nCuota mensual anual: %.2f\n", cuota_mensual_anual);

      return 0;
  }
